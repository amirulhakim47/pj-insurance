// Vehicle Types
export type VehicleType = 'car' | 'motorcycle';

// Customer Types
export type CustomerType = 'individual' | 'company';

// Form Input Interface - Use the type from validations.ts instead
// This is kept for backward compatibility but the actual type is inferred from insuranceFormSchema
import type { InsuranceFormData } from '@/lib/validations';
export type { InsuranceFormData };

// Re-export Allianz types used throughout the app
export type {
  TransactionType,
  IdentityType,
  Gender,
  MaritalStatus,
  VehicleDetailsResponse,
  NvicItem,
  QuotationResponse,
  AdditionalCoverItem,
  CheckUBBResponse,
  NcdDetailsResponse,
  AllianzFlowState,
  ApiErrorResponse,
} from './allianz';

// Insurance Provider Interface
export interface InsuranceProvider {
  id: string;
  name: string;
  logo: string;
  trustScore: number;
}

// Insurance Policy Interface
export interface InsurancePolicy {
  id: string;
  provider: InsuranceProvider;
  startDate: string;
  expiryDate: string;
  description: string;
  features: string[];
  originalPrice: number;
  discountPercentage?: number;
  finalPrice: number;
  isRecommended?: boolean;
  coverage: {
    liability: string;
    comprehensive: boolean;
    theft: boolean;
    flood: boolean;
    windscreen: boolean;
  };
  loading?: boolean;
}

// Form Validation Errors
export interface FormErrors {
  fullName?: string;
  vehicleType?: string;
  nric?: string;
  plateNumber?: string;
  postcode?: string;
  phoneNumber?: string;
  email?: string;
  customerType?: string;
  isEhailing?: string;
  isElectricVehicle?: string;
  pdpaConsent?: string;
}

// API Response Types
export interface PolicySearchResponse {
  success: boolean;
  data: InsurancePolicy[];
  message?: string;
}

// WhatsApp Message Data
export interface WhatsAppMessageData {
  customerInfo: InsuranceFormData;
  selectedPolicy: InsurancePolicy;
  timestamp: string;
}

// Loading State
export interface LoadingState {
  isLoading: boolean;
  progress: number;
  message: string;
}

// Navigation State
export interface NavigationState {
  currentStep: 'form' | 'loading' | 'results' | 'payment' | 'confirmation';
  formData?: InsuranceFormData;
  selectedPolicy?: InsurancePolicy;
}
