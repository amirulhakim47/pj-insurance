/** Session keys for the DC Auto → Allianz quotation journey. */
export const INSURANCE_FORM_DATA_KEY = 'insuranceFormData';
export const INSURANCE_FORM_DRAFT_KEY = 'insuranceFormDraft';
export const ALLIANZ_IS_DEMO_KEY = 'allianz_isDemo';

/** Copy submitted step-1 data back into the form draft so `/quote` can repopulate fields. */
export function restoreInsuranceFormDraftFromSubmitted(): void {
  if (typeof sessionStorage === 'undefined') return;
  const submitted = sessionStorage.getItem(INSURANCE_FORM_DATA_KEY);
  if (!submitted) return;
  sessionStorage.setItem(INSURANCE_FORM_DRAFT_KEY, submitted);
}

export function vehicleDetailsPagePath(options?: { demo?: boolean }): string {
  return options?.demo ? '/quote?demo=true' : '/quote';
}
